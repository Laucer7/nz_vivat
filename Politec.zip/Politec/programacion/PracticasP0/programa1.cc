 #include <iostream>     //include iostream library
using namespace std;    /*avoiding to put std:: before
                        before the library's command */
// **************** MAIN PROGRAM ***************
int main() {      //Function name. Always should be this one
    int edad;     //Creating Age variable
    
    cout << "Introduce tu edad ";
    cin >> edad;
    cout << "Has vivido "<< edad*365*24*60*60; 
    cout << " segundos, aproximadamente" << endl; 
    return 0; 
} 