
:- use_module('pl-man-game/main.pl').

do(move(left)) :- see(normal, left, '.').


do(get(left)) :- see(normal, left, 'U').
do(drop(right)) :- see(normal, left, 'V'), see(normal, right, ' '). 
do(get(left)) :- see(normal, left, 'V').



