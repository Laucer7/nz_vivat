
:- use_module('pl-man-game/main.pl').

do(move(right)) :- see(normal, right, '.').

